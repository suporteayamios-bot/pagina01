
export const CONTACT_INFO = {
  phone: "73998381969",
  phoneFormatted: "(73) 99838-1969",
  email: "contato@lucasbittencourt.adv.br",
  address: "Atendimento em todo Brasil - Online & Presencial",
  whatsappUrl: "https://wa.me/5573998381969"
};

export const NAVIGATION_LINKS = [
  { label: 'Serviços', href: '#servicos' },
  { label: 'Sobre', href: '#sobre' },
  { label: 'Diferenciais', href: '#diferenciais' },
  { label: 'Contato', href: '#contato' },
];
